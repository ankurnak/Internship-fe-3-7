import RegisterForm from "./containers/RegisterForm";

export default RegisterForm;
