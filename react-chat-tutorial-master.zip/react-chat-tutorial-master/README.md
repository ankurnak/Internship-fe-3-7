Клиентская часть чата разрабатываемого по курсу - [Разработка чата на ReactJS + NodeJS](https://www.youtube.com/watch?v=iAV8TPaNt_A&list=PL0FGkDGJQjJFDr8R3D6dFVa1nhce_2-ly)

**Stack:**

- ReactJS
- Redux
- React Router
- Axios
- Ant Design
- date-fns
- Formik
